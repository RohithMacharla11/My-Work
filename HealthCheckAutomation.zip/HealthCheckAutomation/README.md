# HealthCheckAutomation

Automates the manual "Health Check" extract you were doing via prompts: given the
flat main extract (Application Name, Record Type, file Name, etc.) and the 3
SIZE_PARTS workbooks, it derives, per unique (Application Name, Record Type,
File Name Pattern) scenario:

1. Frequency Type (Daily/Weekly/Monthly/Quarterly/Yearly)
2. Frequency Day
3. Expected Start Time
4. Expected End Time
5. Excluding Day
6. Minimum File Size
7. Maximum File Size

and writes a formatted `Final_Health_Check.xlsx` with a second **Issues** sheet
listing every gap/assumption it had to make, instead of silently guessing.

## Project layout

```
HealthCheckAutomation.sln
src/
  HealthCheckAutomation.Core/     <- all the logic, no Excel/IO dependency, unit-testable
    Models/                       ExtractRecord, SizePartRecord, HealthCheckOutputRow, ...
    Services/
      DateTimeExtractor.cs        pulls date/time candidates out of a file name
      DateFormatResolver.cs       resolves MMDDYYYY vs DDMMYYYY ambiguity per scenario
      FileNamePatternGrouper.cs   auto-detects distinct file-name patterns within one App+RecordType
      TimerJobRounder.cs          reverses the 30-minute ingestion timer-job rounding
      CadenceClassifier.cs        Daily/Weekly/Monthly/Quarterly/Yearly via gap statistics
      ExcludingDayCalculator.cs   which weekday(s) never appear
      SizeAggregator.cs           min/max file size, never guesses missing values
    Engine/
      HealthCheckEngine.cs        orchestrates the whole pipeline per scenario
  HealthCheckAutomation.App/      console app - Excel in/out (ClosedXML), CLI entry point
    ExcelIO/
      HeaderMap.cs                header-name-based column lookup (tolerant of spacing/casing)
      ExtractReader.cs            reads the main extract
      SizePartsReader.cs          reads all workbooks in the SIZE_PARTS folder
      ResultWriter.cs             writes the formatted output workbook
    Program.cs
```

## How to build & run

Requires the .NET 8 SDK and internet access to restore ClosedXML from NuGet
(this was built without either available in the environment it was written in,
so it has **not** been compiled/tested yet - see "Known gaps" below).

```bash
dotnet restore
dotnet build

dotnet run --project src/HealthCheckAutomation.App -- \
    "C:\path\to\Final_health_check_template.xlsx" \
    "C:\path\to\extract.xlsx" \
    "C:\path\to\SIZE_PARTS" \
    "C:\path\to\Final_Health_Check.xlsx"
```

**IMPORTANT - this is now template-driven, not auto-derived.** The set of scenarios
comes from the pattern template workbook (Application Name / Record Type / File
pattern / contacts - one row per KNOWN scenario, matching what your SRMS codebase
already tracks). The engine does not invent patterns anymore; it fills in the 7
columns for each template row by regex-matching extract file names against that
row's pattern. Extract files that match no pattern for their App+RecordType land
in the "Unmatched Files" sheet instead of silently vanishing or spawning a new row.

## Key design decisions (per your answers)

**Pattern detection (no hand-written regex per Application+RecordType):**
`FileNamePatternGrouper` masks every 4-8 digit run in a file name with `{D}`
and treats the resulting template as the pattern key. Two file names collapse
into the same scenario only if they're identical once dates/times are masked
out - so an Application+RecordType with genuinely different file layouts
splits into separate scenarios automatically, and a single layout that just
has different dates stays as one scenario.

**Null handling (nothing is guessed):**
- A row with no file name, or a file name with no extractable date, and no
  usable fallback date (Reportdate / ReportdateCalc / Created Date) is
  **excluded from every date-driven calculation** (cadence, times, excluding
  day) but still counted in `Total Files` and flagged in the `Issues` column/
  sheet - so you can see the gap instead of it silently skewing results.
- Missing file sizes are excluded from Min/Max, never treated as 0 - and the
  count of rows missing size data is reported per scenario.
- If gap statistics don't cleanly fall into any Daily/Weekly/Monthly/
  Quarterly/Yearly band, Frequency Type is set to `Unknown` and flagged for
  manual review rather than forced into the nearest bucket.
- Format ambiguity (e.g. `03042026`) is resolved using the **majority format
  found elsewhere in the same scenario** (unambiguous tokens where day > 12
  settle the question on their own); if a scenario has zero unambiguous
  evidence at all, it defaults to DDMMYYYY and is left undocumented as a
  silent risk - flag this to me if that default is wrong for your data and
  I'll change it to raise an Issue instead.

**Timer job rounding:** applied only to Expected Start Time (round down to
the top of the 30-minute window: minutes ≤30 → :00, minutes >30 → :30).
Expected End Time uses the raw stamped time, per your original logic.

## Known gaps / things to confirm against your real files

1. **SIZE_PARTS column headers are guessed** (`ApplicationName`, `RecordType`,
   `FileName`/`Name`, `FileSize`) - `SizePartsReader.cs` needs the exact header
   text from your 3 workbooks; send me those and I'll lock the mapping down
   (right now it'll just skip a sheet silently if it can't find the columns).
2. **Not compiled/run yet** - this environment has no .NET SDK and no internet
   access to restore NuGet packages, so this is a first pass written directly
   against the spec, not verified end-to-end. Please `dotnet build` on your
   side and send me any compile errors - I'll fix them immediately.
3. **Performance on 6 lakh+ rows** - current implementation is fully in-memory
   (`List<T>` + LINQ). This should be fine for 6 lakh rows on any reasonable
   machine, but if you get toward 1 crore we'll want to switch the grouping
   to a streaming/batched read instead of loading everything at once - let's
   see your 6-lakh timing first before optimizing further.
4. **DispositionInMonths / ArchiveDurationInDays / LegalHold etc.** are read
   and carried through on `ExtractRecord` but not yet used anywhere in the
   output - let me know if any of the 7 columns should actually factor them in.
