namespace HealthCheckAutomation.Core.Services;

/// <summary>
/// Works out which day(s) of the week NEVER appear in a scenario's date data -
/// i.e. days the file is never expected. If both Saturday and Sunday are absent,
/// reports "Weekends" instead of listing them individually. If more than 3 days
/// are absent (i.e. files only show up on 3 or fewer distinct weekdays), also
/// collapses to "Weekends" as a safe generalisation rather than a long day list -
/// tune ExplicitListMaxAbsentDays if you'd rather always see the explicit list.
/// </summary>
public class ExcludingDayCalculator
{
    public int ExplicitListMaxAbsentDays = 3;

    public string Calculate(List<DateOnly> distinctDates)
    {
        if (distinctDates.Count == 0) return "";

        var present = distinctDates.Select(d => d.DayOfWeek).ToHashSet();
        var allDays = Enum.GetValues<DayOfWeek>();
        var absent = allDays.Where(d => !present.Contains(d)).ToList();

        if (absent.Count == 0) return ""; // every weekday appears - nothing excluded

        bool bothWeekendDaysAbsent = absent.Contains(DayOfWeek.Saturday) && absent.Contains(DayOfWeek.Sunday);

        if (absent.Count <= ExplicitListMaxAbsentDays && !bothWeekendDaysAbsent)
            return string.Join(", ", OrderedByWeek(absent));

        return bothWeekendDaysAbsent ? "Weekends" : string.Join(", ", OrderedByWeek(absent));
    }

    private static IEnumerable<DayOfWeek> OrderedByWeek(IEnumerable<DayOfWeek> days) =>
        days.OrderBy(d => ((int)d + 6) % 7); // Monday..Sunday order
}
