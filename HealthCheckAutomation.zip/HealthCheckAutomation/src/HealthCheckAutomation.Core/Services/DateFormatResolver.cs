using HealthCheckAutomation.Core.Models;

namespace HealthCheckAutomation.Core.Services;

/// <summary>
/// Resolves genuine format ambiguity (e.g. "03042026" is valid as both MMDDYYYY and
/// DDMMYYYY) for a whole group of file names at once, following the same heuristic
/// used manually: a token where the "day" slot is > 12 can only be one format
/// (that resolves itself during extraction - see DateTimeExtractor). For the
/// remaining genuinely ambiguous tokens, we pick whichever format is most common
/// among the *unambiguous* tokens in the same group, and fall back to DDMMYYYY
/// if there's no unambiguous evidence at all.
/// </summary>
public class DateFormatResolver
{
    public string ResolveGroupPreference(IEnumerable<FileNameExtraction> filesInGroup)
    {
        var votes = new Dictionary<string, int>();

        foreach (var file in filesInGroup)
        {
            var byDate = file.Candidates.GroupBy(c => c.SegmentIndex);
            foreach (var g in byDate)
            {
                var unambiguous = g.Where(c => !c.IsAmbiguous).ToList();
                foreach (var c in unambiguous)
                {
                    votes.TryGetValue(c.FormatGuess, out var count);
                    votes[c.FormatGuess] = count + 1;
                }
            }
        }

        if (votes.Count == 0) return "DDMMYYYY"; // no unambiguous evidence anywhere - safe, documented default

        return votes.OrderByDescending(v => v.Value).First().Key;
    }

    /// <summary>Pick the final date for one file, given the group's resolved format preference.</summary>
    public DateCandidate? ResolveFinal(FileNameExtraction file, string groupPreferredFormat)
    {
        // group candidates by which segment/token they came from, take the earliest usable date per file.
        foreach (var group in file.Candidates.GroupBy(c => c.SegmentIndex))
        {
            var list = group.ToList();
            if (list.Count == 1) return list[0];

            var preferred = list.FirstOrDefault(c => c.FormatGuess == groupPreferredFormat);
            if (preferred != null) return preferred;

            return list[0]; // fallback - shouldn't normally hit this
        }
        return null;
    }
}
