namespace HealthCheckAutomation.Core.Services;

public class SizeAggregationResult
{
    public double? MinBytes { get; set; }
    public double? MaxBytes { get; set; }
    public int ValidCount { get; set; }
    public int MissingCount { get; set; }
}

/// <summary>
/// Aggregates min/max file size for a scenario. Missing values (null, blank, "N/A")
/// are never guessed at or defaulted to zero - they're simply excluded from the
/// min/max calculation and counted separately so the gap is visible in the audit
/// trail instead of silently producing a misleading number.
/// </summary>
public class SizeAggregator
{
    public SizeAggregationResult Aggregate(IEnumerable<double?> sizes)
    {
        var valid = sizes.Where(s => s.HasValue).Select(s => s!.Value).ToList();
        var missing = sizes.Count() - valid.Count;

        return new SizeAggregationResult
        {
            MinBytes = valid.Count > 0 ? valid.Min() : null,
            MaxBytes = valid.Count > 0 ? valid.Max() : null,
            ValidCount = valid.Count,
            MissingCount = missing
        };
    }
}
