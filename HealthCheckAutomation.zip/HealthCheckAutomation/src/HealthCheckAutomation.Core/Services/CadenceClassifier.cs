namespace HealthCheckAutomation.Core.Services;

public class CadenceResult
{
    public string FrequencyType { get; set; } = "Unknown";
    public string FrequencyDay { get; set; } = "";
    public double MeanGapDays { get; set; }
    public double StdDevGapDays { get; set; }
}

/// <summary>
/// Classifies how often a scenario's files show up, from the sorted, de-duplicated
/// set of dates seen for that scenario, using gap statistics between consecutive dates.
/// Thresholds are centralised here (not magic numbers scattered around) so they can
/// be tuned later against real accuracy numbers.
/// </summary>
public class CadenceClassifier
{
    // ---- tunable thresholds ----
    public double DailyMeanMin = 0.5, DailyMeanMax = 1.5, DailyStdDevMax = 1.5;
    public double WeeklyMeanMin = 6.0, WeeklyMeanMax = 8.0, WeeklyStdDevMax = 2.0;
    public double MonthlyMeanMin = 25.0, MonthlyMeanMax = 35.0;
    public double QuarterlyMeanMin = 75.0, QuarterlyMeanMax = 105.0;   // ~2.5-3.5 months
    public double YearlyMeanMin = 330.0, YearlyMeanMax = 400.0;

    public CadenceResult Classify(List<DateOnly> distinctSortedDates)
    {
        var result = new CadenceResult();
        if (distinctSortedDates.Count == 0) { result.FrequencyType = "Unknown"; return result; }
        if (distinctSortedDates.Count == 1) { result.FrequencyType = "Unknown"; return result; } // not enough data to infer cadence

        var gaps = new List<double>();
        for (int i = 1; i < distinctSortedDates.Count; i++)
            gaps.Add((distinctSortedDates[i].ToDateTime(TimeOnly.MinValue) - distinctSortedDates[i - 1].ToDateTime(TimeOnly.MinValue)).TotalDays);

        var mean = gaps.Average();
        var variance = gaps.Sum(g => Math.Pow(g - mean, 2)) / gaps.Count;
        var stdDev = Math.Sqrt(variance);

        result.MeanGapDays = mean;
        result.StdDevGapDays = stdDev;

        if (mean >= DailyMeanMin && mean <= DailyMeanMax && stdDev < DailyStdDevMax)
            result.FrequencyType = "Daily";
        else if (mean >= WeeklyMeanMin && mean <= WeeklyMeanMax && stdDev < WeeklyStdDevMax)
            result.FrequencyType = "Weekly";
        else if (mean >= MonthlyMeanMin && mean <= MonthlyMeanMax)
            result.FrequencyType = "Monthly";
        else if (mean >= QuarterlyMeanMin && mean <= QuarterlyMeanMax)
            result.FrequencyType = "Quarterly";
        else if (mean >= YearlyMeanMin && mean <= YearlyMeanMax)
            result.FrequencyType = "Yearly";
        else
            result.FrequencyType = "Unknown"; // don't guess - flag for manual review instead

        result.FrequencyDay = DeriveFrequencyDay(result.FrequencyType, distinctSortedDates);
        return result;
    }

    private static string DeriveFrequencyDay(string frequencyType, List<DateOnly> dates)
    {
        switch (frequencyType)
        {
            case "Daily":
                return ""; // no single day for daily

            case "Weekly":
                return dates.GroupBy(d => d.DayOfWeek)
                    .OrderByDescending(g => g.Count())
                    .First().Key.ToString();

            case "Monthly":
            case "Quarterly":
            case "Yearly":
                return dates.GroupBy(d => d.Day)
                    .OrderByDescending(g => g.Count())
                    .First().Key.ToString();

            default:
                return "";
        }
    }
}
