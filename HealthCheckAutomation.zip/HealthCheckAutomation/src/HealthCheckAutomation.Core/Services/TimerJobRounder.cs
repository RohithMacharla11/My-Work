namespace HealthCheckAutomation.Core.Services;

/// <summary>
/// The ingestion timer job runs every 30 minutes and stamps the file name with the
/// time of the run that picked the file up, not the time the file actually landed.
/// So a file that arrived at 11:01 gets named with "11:30", and one that arrived at
/// 11:29 also gets named "11:30". This class reverses that: given the raw stamped
/// time, round DOWN to the start of the 30-minute window it must have come from.
///
///   minutes <= 30 -> round down to :00 of that hour
///   minutes >  30 -> round down to :30 of that hour
///
/// Used only for Expected Start Time. Expected End Time intentionally uses the raw
/// (non-adjusted) stamped time, since that already represents the latest point by
/// which the file is guaranteed to exist.
/// </summary>
public static class TimerJobRounder
{
    public static TimeOnly RoundDownToTimerWindow(TimeOnly raw)
    {
        return raw.Minute <= 30
            ? new TimeOnly(raw.Hour, 0)
            : new TimeOnly(raw.Hour, 30);
    }
}
