using System.Text;
using System.Text.RegularExpressions;

namespace HealthCheckAutomation.Core.Services;

/// <summary>
/// Automatically derives a "pattern" for a file name by masking out the parts that
/// vary from file to file (date/time digit runs), so that two file names collapse
/// into the same pattern only when everything BUT the date/time is identical.
///
/// This is what lets the same (ApplicationName, RecordType) split into several
/// distinct scenarios when it actually contains more than one file layout, without
/// needing a hand-written regex per combination.
/// </summary>
public class FileNamePatternGrouper
{
    private static readonly Regex DigitRun = new(@"\d{4,8}", RegexOptions.Compiled);

    /// <summary>Returns a stable, human-readable template such as "AML_Report_{D}_{D}.csv".</summary>
    public string DeriveTemplate(string fileName)
    {
        var extIdx = fileName.LastIndexOf('.');
        var namePart = extIdx > 0 ? fileName[..extIdx] : fileName;
        var ext = extIdx > 0 ? fileName[extIdx..] : "";

        var masked = DigitRun.Replace(namePart, "{D}");
        return masked + ext;
    }

    /// <summary>Group a set of (fileName) values into pattern buckets, keyed by the derived template.</summary>
    public Dictionary<string, List<string>> GroupByPattern(IEnumerable<string> fileNames)
    {
        var buckets = new Dictionary<string, List<string>>();
        foreach (var name in fileNames)
        {
            if (string.IsNullOrWhiteSpace(name)) continue;
            var template = DeriveTemplate(name);
            if (!buckets.TryGetValue(template, out var list))
            {
                list = new List<string>();
                buckets[template] = list;
            }
            list.Add(name);
        }
        return buckets;
    }
}
