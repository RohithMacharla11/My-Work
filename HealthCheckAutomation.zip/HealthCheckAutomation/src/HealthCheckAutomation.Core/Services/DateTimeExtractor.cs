using System.Text.RegularExpressions;
using HealthCheckAutomation.Core.Models;

namespace HealthCheckAutomation.Core.Services;

/// <summary>
/// Pulls date/time tokens out of a file name. Mirrors the logic that was worked out
/// manually (see project notes): strip extension, split on _ - ., look at digit runs
/// of 4-8 in the last few segments, try every plausible date format, validate
/// month/day ranges, and pick up an adjacent time token if there is one.
///
/// Format ambiguity (e.g. "03042026" could be MMDDYYYY or DDMMYYYY) is NOT resolved
/// here - this class returns every valid candidate reading for a token, and
/// <see cref="DateFormatResolver"/> picks the final one per group.
/// </summary>
public class DateTimeExtractor
{
    private static readonly Regex DigitToken = new(@"\d{4,8}", RegexOptions.Compiled);
    private static readonly Regex TimeToken4 = new(@"^(\d{2})(\d{2})$", RegexOptions.Compiled);      // HHmm
    private static readonly Regex TimeToken6 = new(@"^(\d{2})(\d{2})(\d{2})$", RegexOptions.Compiled); // HHmmss

    public FileNameExtraction Extract(string fileName)
    {
        var result = new FileNameExtraction { FileName = fileName };

        var noExt = StripExtension(fileName);
        var segments = noExt.Split(new[] { '_', '-', '.' }, StringSplitOptions.RemoveEmptyEntries);
        if (segments.Length == 0) return result;

        // Prioritize the last 5 segments (dates are almost always near the end of the file name).
        int start = Math.Max(0, segments.Length - 5);

        for (int i = start; i < segments.Length; i++)
        {
            var seg = segments[i];
            var m = DigitToken.Match(seg);
            if (!m.Success) continue;

            var token = m.Value;
            var candidates = TryParseDateToken(token);
            if (candidates.Count == 0) continue;

            // Look at the neighbouring segments for a time token (before or after the date segment).
            TimeOnly? time = FindAdjacentTime(segments, i);

            foreach (var c in candidates)
            {
                c.RawToken = token;
                c.SegmentIndex = i;
                c.AdjacentTime = time;
                c.IsAmbiguous = candidates.Count > 1;
                result.Candidates.Add(c);
            }
        }

        return result;
    }

    private static string StripExtension(string fileName)
    {
        var idx = fileName.LastIndexOf('.');
        return idx > 0 ? fileName[..idx] : fileName;
    }

    /// <summary>Try every plausible layout for a digit token and keep only the ones that produce a valid date.</summary>
    private static List<DateCandidate> TryParseDateToken(string token)
    {
        var candidates = new List<DateCandidate>();

        if (token.Length == 8)
        {
            TryAdd(candidates, token, "MMDDYYYY", () => new DateOnly(int.Parse(token[4..8]), int.Parse(token[..2]), int.Parse(token[2..4])));
            TryAdd(candidates, token, "YYYYMMDD", () => new DateOnly(int.Parse(token[..4]), int.Parse(token[4..6]), int.Parse(token[6..8])));
            TryAdd(candidates, token, "DDMMYYYY", () => new DateOnly(int.Parse(token[4..8]), int.Parse(token[2..4]), int.Parse(token[..2])));
        }
        else if (token.Length == 6)
        {
            TryAdd(candidates, token, "MMDDYY", () => new DateOnly(2000 + int.Parse(token[4..6]), int.Parse(token[..2]), int.Parse(token[2..4])));
            TryAdd(candidates, token, "DDMMYY", () => new DateOnly(2000 + int.Parse(token[4..6]), int.Parse(token[2..4]), int.Parse(token[..2])));
        }
        // 4 and 5 digit tokens are treated as pure time tokens elsewhere, not dates.

        // De-duplicate identical (date) results even if format label differs.
        return candidates
            .GroupBy(c => c.Date)
            .Select(g => g.First())
            .ToList();
    }

    private static void TryAdd(List<DateCandidate> list, string token, string formatLabel, Func<DateOnly> build)
    {
        try
        {
            var date = build();
            // Sanity bounds - reject obviously bogus years (extraction pipelines routinely run over ~2015-2035).
            if (date.Year < 2000 || date.Year > 2099) return;
            list.Add(new DateCandidate { FormatGuess = formatLabel, Date = date });
        }
        catch
        {
            // invalid month/day range for this layout - not a candidate
        }
    }

    private static TimeOnly? FindAdjacentTime(string[] segments, int dateSegmentIndex)
    {
        foreach (var idx in new[] { dateSegmentIndex + 1, dateSegmentIndex - 1 })
        {
            if (idx < 0 || idx >= segments.Length) continue;
            var seg = segments[idx];

            var m6 = TimeToken6.Match(seg);
            if (m6.Success)
            {
                var h = int.Parse(m6.Groups[1].Value);
                var mi = int.Parse(m6.Groups[2].Value);
                var se = int.Parse(m6.Groups[3].Value);
                if (IsValidTime(h, mi, se)) return new TimeOnly(h, mi, se);
            }

            var m4 = TimeToken4.Match(seg);
            if (m4.Success)
            {
                var h = int.Parse(m4.Groups[1].Value);
                var mi = int.Parse(m4.Groups[2].Value);
                if (IsValidTime(h, mi, 0)) return new TimeOnly(h, mi);
            }
        }
        return null;
    }

    private static bool IsValidTime(int h, int m, int s) =>
        h is >= 0 and <= 23 && m is >= 0 and <= 59 && s is >= 0 and <= 59;
}
