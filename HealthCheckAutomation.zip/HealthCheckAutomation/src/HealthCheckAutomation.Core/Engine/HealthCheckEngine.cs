using HealthCheckAutomation.Core.Models;
using HealthCheckAutomation.Core.Services;

namespace HealthCheckAutomation.Core.Engine;

/// <summary>
/// Top-level orchestrator: takes the raw extract rows + the size-part rows and
/// produces one HealthCheckOutputRow per unique (ApplicationName, RecordType,
/// FileNamePattern) scenario.
///
/// Pipeline per scenario:
///   1. Extract date/time candidates from every file name in the group.
///   2. Resolve month/day format ambiguity using the whole group as context.
///   3. Fall back to Reportdate / ReportdateCalc / Created Date for rows whose
///      file name yielded no date at all.
///   4. Classify cadence (Frequency Type / Day) from the resulting date set.
///   5. Derive Expected Start Time (timer-job-rounded, earliest) and
///      Expected End Time (raw, latest).
///   6. Derive Excluding Day from the weekday coverage of the date set.
///   7. Match size-part rows to this scenario and aggregate min/max file size.
///
/// Rows that can't be dated at all (no file-name date AND no fallback date) are
/// still counted in the group (they prove the scenario exists / affect the file
/// count) but are excluded from every date-driven calculation - never guessed.
/// </summary>
public class HealthCheckEngine
{
    private readonly FileNamePatternGrouper _patternGrouper = new();
    private readonly DateTimeExtractor _dateExtractor = new();
    private readonly DateFormatResolver _formatResolver = new();
    private readonly CadenceClassifier _cadenceClassifier = new();
    private readonly ExcludingDayCalculator _excludingDayCalculator = new();
    private readonly SizeAggregator _sizeAggregator = new();

    public List<HealthCheckOutputRow> Run(List<ExtractRecord> extract, List<SizePartRecord> sizeParts)
    {
        var output = new List<HealthCheckOutputRow>();

        var appRecordGroups = extract
            .Where(r => !string.IsNullOrWhiteSpace(r.ApplicationName) && !string.IsNullOrWhiteSpace(r.RecordType))
            .GroupBy(r => (App: r.ApplicationName!.Trim(), Record: r.RecordType!.Trim()));

        foreach (var appRecordGroup in appRecordGroups)
        {
            var withNames = appRecordGroup.Where(r => !string.IsNullOrWhiteSpace(r.Name)).ToList();
            var patternBuckets = _patternGrouper.GroupByPattern(withNames.Select(r => r.Name!));

            // Re-attach the actual ExtractRecord rows to each pattern bucket.
            var recordsByFileName = withNames
                .GroupBy(r => r.Name!)
                .ToDictionary(g => g.Key, g => g.ToList());

            foreach (var (template, fileNames) in patternBuckets)
            {
                var rowsInScenario = fileNames.SelectMany(fn => recordsByFileName[fn]).ToList();
                var row = BuildScenarioRow(appRecordGroup.Key.App, appRecordGroup.Key.Record, template, rowsInScenario, sizeParts);
                output.Add(row);
            }

            // Rows with no Name at all can't be pattern-grouped - report them as their own "unknown pattern" bucket
            // so nothing silently disappears from the health check.
            var noName = appRecordGroup.Where(r => string.IsNullOrWhiteSpace(r.Name)).ToList();
            if (noName.Count > 0)
            {
                var row = BuildScenarioRow(appRecordGroup.Key.App, appRecordGroup.Key.Record, "(no file name)", noName, sizeParts);
                row.AddIssue($"{noName.Count} row(s) had no file name at all - grouped separately, dates taken from fallback columns only.");
                output.Add(row);
            }
        }

        return output;
    }

    private HealthCheckOutputRow BuildScenarioRow(string app, string recordType, string pattern,
        List<ExtractRecord> rows, List<SizePartRecord> sizeParts)
    {
        var row = new HealthCheckOutputRow
        {
            ApplicationName = app,
            RecordType = recordType,
            FileNamePattern = pattern,
            TotalFilesInGroup = rows.Count
        };

        // --- 1+2+3: extract + resolve date/time per row ---
        var extractions = rows
            .Where(r => !string.IsNullOrWhiteSpace(r.Name))
            .Select(r => (Record: r, Extraction: _dateExtractor.Extract(r.Name!)))
            .ToList();

        var preferredFormat = _formatResolver.ResolveGroupPreference(extractions.Select(e => e.Extraction));

        var resolvedDates = new List<DateOnly>();
        var rawStartTimes = new List<TimeOnly>();  // for expected start time (timer-job-rounded, earliest)
        var rawEndTimes = new List<TimeOnly>();    // for expected end time (raw, latest)
        int unparsed = 0;

        foreach (var (record, extraction) in extractions)
        {
            var final = _formatResolver.ResolveFinal(extraction, preferredFormat);
            if (final != null)
            {
                resolvedDates.Add(final.Date);
                if (final.AdjacentTime.HasValue)
                {
                    rawStartTimes.Add(TimerJobRounder.RoundDownToTimerWindow(final.AdjacentTime.Value));
                    rawEndTimes.Add(final.AdjacentTime.Value);
                }
            }
            else
            {
                var fallback = TryFallbackDate(record);
                if (fallback.HasValue) resolvedDates.Add(fallback.Value);
                else unparsed++;
            }
        }

        // Rows with no Name field use fallback columns directly.
        foreach (var record in rows.Where(r => string.IsNullOrWhiteSpace(r.Name)))
        {
            var fallback = TryFallbackDate(record);
            if (fallback.HasValue) resolvedDates.Add(fallback.Value);
            else unparsed++;
        }

        row.FilesUnparsedDate = unparsed;
        row.FilesWithParsedDate = row.TotalFilesInGroup - unparsed;
        if (unparsed > 0)
            row.AddIssue($"{unparsed} of {row.TotalFilesInGroup} file(s) had no usable date (file name or fallback columns) - excluded from cadence/time/excluding-day calculations.");

        var distinctSortedDates = resolvedDates.Distinct().OrderBy(d => d).ToList();

        // --- 4: cadence ---
        var cadence = _cadenceClassifier.Classify(distinctSortedDates);
        row.FrequencyType = cadence.FrequencyType;
        row.FrequencyDay = cadence.FrequencyDay;
        if (cadence.FrequencyType == "Unknown" && distinctSortedDates.Count > 0)
            row.AddIssue($"Gap pattern (mean {cadence.MeanGapDays:F1}d, stdDev {cadence.StdDevGapDays:F1}d) didn't match any known cadence band - needs manual review.");

        // --- 5: expected start/end time ---
        if (rawStartTimes.Count > 0)
            row.ExpectedStartTime = rawStartTimes.Min().ToString("HH:mm");
        else if (distinctSortedDates.Count > 0)
            row.AddIssue("No time token found in any file name for this scenario - Expected Start Time left blank rather than guessed.");

        if (rawEndTimes.Count > 0)
            row.ExpectedEndTime = rawEndTimes.Max().ToString("HH:mm");

        // --- 6: excluding day ---
        row.ExcludingDay = _excludingDayCalculator.Calculate(distinctSortedDates);

        // --- 7: size matching ---
        var matchedSizes = MatchSizes(app, recordType, rows, sizeParts);
        var sizeResult = _sizeAggregator.Aggregate(matchedSizes);
        row.MinimumFileSizeBytes = sizeResult.MinBytes;
        row.MaximumFileSizeBytes = sizeResult.MaxBytes;
        row.FilesWithSize = sizeResult.ValidCount;
        row.FilesMissingSize = sizeResult.MissingCount;
        if (sizeResult.ValidCount == 0)
            row.AddIssue("No matching file-size data found in SIZE_PARTS for this scenario.");

        return row;
    }

    private static DateOnly? TryFallbackDate(ExtractRecord record)
    {
        if (record.Reportdate.HasValue) return DateOnly.FromDateTime(record.Reportdate.Value);
        if (record.ReportdateCalc.HasValue) return DateOnly.FromDateTime(record.ReportdateCalc.Value);
        if (record.CreatedDate.HasValue) return DateOnly.FromDateTime(record.CreatedDate.Value);
        return null;
    }

    private List<double?> MatchSizes(string app, string recordType, List<ExtractRecord> rows, List<SizePartRecord> sizeParts)
    {
        var fileNames = rows.Where(r => !string.IsNullOrWhiteSpace(r.Name)).Select(r => r.Name!.Trim()).ToHashSet(StringComparer.OrdinalIgnoreCase);

        // Primary match: exact ApplicationName + RecordType + FileName.
        var exact = sizeParts.Where(sp =>
            string.Equals(sp.ApplicationName?.Trim(), app, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(sp.RecordType?.Trim(), recordType, StringComparison.OrdinalIgnoreCase) &&
            !string.IsNullOrWhiteSpace(sp.FileName) &&
            fileNames.Contains(sp.FileName.Trim()))
            .ToList();

        if (exact.Count > 0)
            return exact.Select(sp => sp.FileSizeBytes).ToList();

        // Fallback: same App + RecordType, any file (SIZE_PARTS naming may not exactly match extract naming) -
        // still scoped tightly by App+RecordType so we never borrow sizes from an unrelated scenario.
        return sizeParts.Where(sp =>
            string.Equals(sp.ApplicationName?.Trim(), app, StringComparison.OrdinalIgnoreCase) &&
            string.Equals(sp.RecordType?.Trim(), recordType, StringComparison.OrdinalIgnoreCase))
            .Select(sp => sp.FileSizeBytes)
            .ToList();
    }
}
