using HealthCheckAutomation.Core.Models;
using HealthCheckAutomation.Core.Services;

namespace HealthCheckAutomation.Core.Engine;

/// <summary>
/// Top-level orchestrator - TEMPLATE-DRIVEN. The set of scenarios is NOT derived from
/// the extract: it comes from the pattern template (ApplicationName, RecordType,
/// FilePattern regex, one row per known scenario). This engine's job is to fill in
/// the 7 columns for each of those known rows, by matching extract file names
/// against each row's regex, scoped to that row's ApplicationName + RecordType.
///
/// Pipeline per template row:
///   1. Find every extract row with the same ApplicationName + RecordType whose
///      file name matches this row's regex.
///   2. Extract date/time candidates from each matched file name.
///   3. Resolve month/day format ambiguity using the whole matched set as context.
///   4. Fall back to Reportdate / ReportdateCalc / Created Date for rows whose
///      file name yielded no date at all.
///   5. Classify cadence (Frequency Type / Day) from the resulting date set.
///   6. Derive Expected Start Time (timer-job-rounded, earliest) and
///      Expected End Time (raw, latest).
///   7. Derive Excluding Day from the weekday coverage of the date set.
///   8. Match size-part rows to this scenario and aggregate min/max file size.
///
/// Extract rows whose file name matches NO pattern defined for their App+RecordType
/// are collected separately (see UnmatchedFiles on the result) - a real gap that
/// needs either a new template row or a fix to an existing pattern, never silently
/// dropped or force-matched.
/// </summary>
public class HealthCheckEngine
{
    private readonly DateTimeExtractor _dateExtractor = new();
    private readonly DateFormatResolver _formatResolver = new();
    private readonly CadenceClassifier _cadenceClassifier = new();
    private readonly ExcludingDayCalculator _excludingDayCalculator = new();
    private readonly SizeAggregator _sizeAggregator = new();

    public class Result
    {
        public List<HealthCheckOutputRow> Rows { get; set; } = new();
        public List<UnmatchedFile> UnmatchedFiles { get; set; } = new();
    }

    public Result Run(List<PatternRule> patterns, List<ExtractRecord> extract, List<SizePartRecord> sizeParts)
    {
        foreach (var p in patterns) p.Compile();

        // Index extract rows by (ApplicationName, RecordType) once, so we don't rescan
        // the full 650k-row extract for every one of the ~200 template rows.
        var extractByAppRecord = new Dictionary<(string App, string Record), List<ExtractRecord>>();
        foreach (var r in extract)
        {
            if (string.IsNullOrWhiteSpace(r.ApplicationName) || string.IsNullOrWhiteSpace(r.RecordType) || string.IsNullOrWhiteSpace(r.Name))
                continue;
            var key = (r.ApplicationName.Trim().ToLowerInvariant(), r.RecordType.Trim().ToLowerInvariant());
            if (!extractByAppRecord.TryGetValue(key, out var list))
            {
                list = new List<ExtractRecord>();
                extractByAppRecord[key] = list;
            }
            list.Add(r);
        }

        // Size lookups, same O(1)-per-scenario indexing as before.
        var exactSizeIndex = new Dictionary<(string App, string Record, string FileName), List<double?>>();
        var groupSizeIndex = new Dictionary<(string App, string Record), List<double?>>();
        foreach (var sp in sizeParts)
        {
            var app = sp.ApplicationName?.Trim().ToLowerInvariant() ?? "";
            var rec = sp.RecordType?.Trim().ToLowerInvariant() ?? "";
            var groupKey = (app, rec);
            if (!groupSizeIndex.TryGetValue(groupKey, out var groupList))
            {
                groupList = new List<double?>();
                groupSizeIndex[groupKey] = groupList;
            }
            groupList.Add(sp.FileSizeBytes);

            if (!string.IsNullOrWhiteSpace(sp.FileName))
            {
                var exactKey = (app, rec, sp.FileName.Trim().ToLowerInvariant());
                if (!exactSizeIndex.TryGetValue(exactKey, out var exactList))
                {
                    exactList = new List<double?>();
                    exactSizeIndex[exactKey] = exactList;
                }
                exactList.Add(sp.FileSizeBytes);
            }
        }

        var result = new Result();

        // Track, per (App, RecordType, extract row), whether ANY pattern claimed it -
        // used at the end to report unmatched files.
        var claimed = new HashSet<ExtractRecord>();

        foreach (var pattern in patterns)
        {
            var row = new HealthCheckOutputRow
            {
                ApplicationName = pattern.ApplicationName,
                RecordType = pattern.RecordType,
                FileNamePattern = pattern.FilePatternRaw,
                PrimaryBusinessContact = pattern.PrimaryBusinessContact,
                PrimaryITContact = pattern.PrimaryITContact
            };

            if (pattern.CompileError != null)
            {
                row.AddIssue($"Pattern did not compile as a valid regex: {pattern.CompileError}. No files could be matched for this row - fix the pattern text.");
                result.Rows.Add(row);
                continue;
            }

            var key = (pattern.ApplicationName.Trim().ToLowerInvariant(), pattern.RecordType.Trim().ToLowerInvariant());
            var candidateRows = extractByAppRecord.TryGetValue(key, out var list) ? list : new List<ExtractRecord>();
            var matchedRows = candidateRows.Where(r => pattern.IsMatch(r.Name!)).ToList();
            foreach (var r in matchedRows) claimed.Add(r);

            FillScenarioColumns(row, matchedRows, exactSizeIndex, groupSizeIndex);
            result.Rows.Add(row);
        }

        // Anything with a valid App+RecordType+Name that no pattern claimed is a real gap.
        foreach (var kvp in extractByAppRecord)
        {
            var hasAnyPatternForThisAppRecord = patterns.Any(p =>
                p.ApplicationName.Trim().ToLowerInvariant() == kvp.Key.Item1 &&
                p.RecordType.Trim().ToLowerInvariant() == kvp.Key.Item2);

            foreach (var r in kvp.Value)
            {
                if (claimed.Contains(r)) continue;
                result.UnmatchedFiles.Add(new UnmatchedFile
                {
                    ApplicationName = r.ApplicationName!,
                    RecordType = r.RecordType!,
                    FileName = r.Name!,
                    Reason = hasAnyPatternForThisAppRecord
                        ? "Matched no pattern defined for this Application+RecordType - existing pattern(s) may need adjusting."
                        : "No pattern at all defined for this Application+RecordType in the template - needs a new template row."
                });
            }
        }

        return result;
    }

    private void FillScenarioColumns(HealthCheckOutputRow row, List<ExtractRecord> rows,
        Dictionary<(string App, string Record, string FileName), List<double?>> exactSizeIndex,
        Dictionary<(string App, string Record), List<double?>> groupSizeIndex)
    {
        row.TotalFilesInGroup = rows.Count;

        if (rows.Count == 0)
        {
            row.AddIssue("No files in the extract matched this pattern for this Application+RecordType.");
            return;
        }

        // --- extract + resolve date/time per row (wrapped so one bad file name never aborts the run) ---
        var extractions = new List<(ExtractRecord Record, Models.FileNameExtraction Extraction)>();
        int extractionFailures = 0;
        foreach (var r in rows)
        {
            try
            {
                extractions.Add((r, _dateExtractor.Extract(r.Name!)));
            }
            catch
            {
                extractionFailures++;
                extractions.Add((r, new Models.FileNameExtraction { FileName = r.Name! }));
            }
        }

        var preferredFormat = _formatResolver.ResolveGroupPreference(extractions.Select(e => e.Extraction));

        var resolvedDates = new List<DateOnly>();
        var rawStartTimes = new List<TimeOnly>();
        var rawEndTimes = new List<TimeOnly>();
        int unparsed = 0;

        foreach (var (record, extraction) in extractions)
        {
            Models.DateCandidate? final = null;
            try
            {
                final = _formatResolver.ResolveFinal(extraction, preferredFormat);
            }
            catch
            {
                extractionFailures++;
            }

            if (final != null)
            {
                resolvedDates.Add(final.Date);
                if (final.AdjacentTime.HasValue)
                {
                    rawStartTimes.Add(TimerJobRounder.RoundDownToTimerWindow(final.AdjacentTime.Value));
                    rawEndTimes.Add(final.AdjacentTime.Value);
                }
            }
            else
            {
                var fallback = TryFallbackDate(record);
                if (fallback.HasValue) resolvedDates.Add(fallback.Value);
                else unparsed++;
            }
        }

        row.FilesUnparsedDate = unparsed;
        row.FilesWithParsedDate = row.TotalFilesInGroup - unparsed;
        if (unparsed > 0)
            row.AddIssue($"{unparsed} of {row.TotalFilesInGroup} file(s) had no usable date (file name or fallback columns) - excluded from cadence/time/excluding-day calculations.");
        if (extractionFailures > 0)
            row.AddIssue($"{extractionFailures} file name(s) hit a parsing error and were treated as unparsed rather than crashing the run.");

        var distinctSortedDates = resolvedDates.Distinct().OrderBy(d => d).ToList();

        var cadence = _cadenceClassifier.Classify(distinctSortedDates);
        row.FrequencyType = cadence.FrequencyType;
        row.FrequencyDay = cadence.FrequencyDay;
        if (cadence.FrequencyType == "Unknown" && distinctSortedDates.Count > 0)
            row.AddIssue($"Gap pattern (mean {cadence.MeanGapDays:F1}d, stdDev {cadence.StdDevGapDays:F1}d) didn't match any known cadence band - needs manual review.");

        if (rawStartTimes.Count > 0)
            row.ExpectedStartTime = rawStartTimes.Min().ToString("HH:mm");
        else if (distinctSortedDates.Count > 0)
            row.AddIssue("No time token found in any file name for this scenario - Expected Start Time left blank rather than guessed.");

        if (rawEndTimes.Count > 0)
            row.ExpectedEndTime = rawEndTimes.Max().ToString("HH:mm");

        row.ExcludingDay = _excludingDayCalculator.Calculate(distinctSortedDates);

        var matchedSizes = MatchSizes(row.ApplicationName, row.RecordType, rows, exactSizeIndex, groupSizeIndex);
        var sizeResult = _sizeAggregator.Aggregate(matchedSizes);
        row.MinimumFileSizeBytes = sizeResult.MinBytes;
        row.MaximumFileSizeBytes = sizeResult.MaxBytes;
        row.FilesWithSize = sizeResult.ValidCount;
        row.FilesMissingSize = sizeResult.MissingCount;
        if (sizeResult.ValidCount == 0)
            row.AddIssue("No matching file-size data found in SIZE_PARTS for this scenario.");
    }

    private static DateOnly? TryFallbackDate(ExtractRecord record)
    {
        if (record.Reportdate.HasValue) return DateOnly.FromDateTime(record.Reportdate.Value);
        if (record.ReportdateCalc.HasValue) return DateOnly.FromDateTime(record.ReportdateCalc.Value);
        if (record.CreatedDate.HasValue) return DateOnly.FromDateTime(record.CreatedDate.Value);
        return null;
    }

    private List<double?> MatchSizes(string app, string recordType, List<ExtractRecord> rows,
        Dictionary<(string App, string Record, string FileName), List<double?>> exactSizeIndex,
        Dictionary<(string App, string Record), List<double?>> groupSizeIndex)
    {
        var appKey = app.Trim().ToLowerInvariant();
        var recKey = recordType.Trim().ToLowerInvariant();
        var fileNames = rows.Select(r => r.Name!.Trim().ToLowerInvariant()).ToHashSet();

        var exact = new List<double?>();
        foreach (var fn in fileNames)
            if (exactSizeIndex.TryGetValue((appKey, recKey, fn), out var sizes))
                exact.AddRange(sizes);

        if (exact.Count > 0)
            return exact;

        return groupSizeIndex.TryGetValue((appKey, recKey), out var groupSizes)
            ? groupSizes
            : new List<double?>();
    }
}
