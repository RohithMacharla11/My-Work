namespace HealthCheckAutomation.Core.Models;

/// <summary>
/// An extract row whose file name didn't match ANY pattern defined for its
/// (ApplicationName, RecordType) in the template - a real gap: either a new file
/// layout that needs a pattern added to the template, or a typo in an existing one.
/// </summary>
public class UnmatchedFile
{
    public string ApplicationName { get; set; } = "";
    public string RecordType { get; set; } = "";
    public string FileName { get; set; } = "";
    public string Reason { get; set; } = ""; // e.g. "no pattern defined for this App+RecordType" / "matched no pattern (N patterns tried)"
}
