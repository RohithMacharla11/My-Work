namespace HealthCheckAutomation.Core.Models;

/// <summary>
/// One row of the raw main extract, mapped 1:1 to the columns in the source Excel:
/// Applicationname, RecordType, Container Key, Document Key, Name, Reportdate,
/// ReportdateCalc, DocumentArchiveDeleteDate, Created Date, Disposition,
/// DispositionInMonths, DispositionAfter, ArchiveDurationInDays, LegalHold,
/// Status, DataClassification, ItStorageRequirement.
///
/// "Name" is the file name (this is where the date/time is embedded).
/// "Reportdate" / "ReportdateCalc" / "Created Date" are fallback date sources
/// used only when no date can be extracted from the file name itself.
/// </summary>
public class ExtractRecord
{
    public int RowNumber { get; set; }

    public string? ApplicationName { get; set; }
    public string? RecordType { get; set; }
    public string? ContainerKey { get; set; }
    public string? DocumentKey { get; set; }
    public string? Name { get; set; }               // file name

    public DateTime? Reportdate { get; set; }
    public DateTime? ReportdateCalc { get; set; }
    public DateTime? DocumentArchiveDeleteDate { get; set; }
    public DateTime? CreatedDate { get; set; }

    public string? Disposition { get; set; }
    public double? DispositionInMonths { get; set; }
    public string? DispositionAfter { get; set; }
    public double? ArchiveDurationInDays { get; set; }
    public string? LegalHold { get; set; }
    public string? Status { get; set; }
    public string? DataClassification { get; set; }
    public string? ItStorageRequirement { get; set; }

    /// <summary>Key used to group rows: ApplicationName + RecordType (pattern is derived separately).</summary>
    public string AppRecordKey => $"{ApplicationName?.Trim()}||{RecordType?.Trim()}";
}
