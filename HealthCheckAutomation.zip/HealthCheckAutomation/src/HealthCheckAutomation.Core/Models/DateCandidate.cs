namespace HealthCheckAutomation.Core.Models;

/// <summary>One candidate date reading of a digit token found in a file name.</summary>
public class DateCandidate
{
    public string RawToken { get; set; } = "";
    public int SegmentIndex { get; set; }           // which underscore/dash/dot segment it came from
    public string FormatGuess { get; set; } = "";     // "MMDDYYYY" | "YYYYMMDD" | "DDMMYYYY" | "MMDDYY" | "DDMMYY"
    public DateOnly Date { get; set; }
    public bool IsAmbiguous { get; set; }             // true if more than one FormatGuess produced a valid date
    public TimeOnly? AdjacentTime { get; set; }        // time token found next to this date token, if any
}

/// <summary>Everything extracted from a single file name, before format-ambiguity resolution.</summary>
public class FileNameExtraction
{
    public string FileName { get; set; } = "";
    public List<DateCandidate> Candidates { get; set; } = new();
    public bool HasAnyDate => Candidates.Count > 0;
}
