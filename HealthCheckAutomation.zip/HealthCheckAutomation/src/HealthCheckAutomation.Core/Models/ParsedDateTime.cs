namespace HealthCheckAutomation.Core.Models;

public enum DateSource
{
    FileName,
    Reportdate,
    ReportdateCalc,
    CreatedDate,
    None
}

/// <summary>Result of trying to pull a date (and optionally a time) out of one file name / row.</summary>
public class ParsedDateTime
{
    public bool Success { get; set; }
    public DateOnly? Date { get; set; }
    public TimeOnly? Time { get; set; }        // null if the file name had no time token
    public DateSource Source { get; set; } = DateSource.None;

    /// <summary>True when the date came from an 8-digit token whose format (MMDDYYYY vs DDMMYYYY
    /// vs YYYYMMDD) was ambiguous and resolved via the day&gt;12 / most-common-format heuristic.</summary>
    public bool FormatWasAmbiguous { get; set; }

    public static ParsedDateTime Failed() => new() { Success = false, Source = DateSource.None };
}
