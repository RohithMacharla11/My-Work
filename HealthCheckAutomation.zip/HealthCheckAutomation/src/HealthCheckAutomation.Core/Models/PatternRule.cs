using System.Text.RegularExpressions;

namespace HealthCheckAutomation.Core.Models;

/// <summary>
/// One row of the pattern template: a known (ApplicationName, RecordType, FilePattern)
/// scenario that already exists - this is the master list the engine fills in, rather
/// than something it derives. Contacts are carried through untouched to the output.
/// </summary>
public class PatternRule
{
    public int RowNumber { get; set; }
    public string ApplicationName { get; set; } = "";
    public string RecordType { get; set; } = "";
    public string FilePatternRaw { get; set; } = "";
    public string? PrimaryBusinessContact { get; set; }
    public string? PrimaryITContact { get; set; }

    public Regex? CompiledPattern { get; private set; }
    public string? CompileError { get; private set; }

    public void Compile()
    {
        try
        {
            CompiledPattern = new Regex(FilePatternRaw, RegexOptions.IgnoreCase | RegexOptions.Compiled);
        }
        catch (Exception ex)
        {
            CompileError = ex.Message;
        }
    }

    public bool IsMatch(string fileName) => CompiledPattern != null && CompiledPattern.IsMatch(fileName);
}
