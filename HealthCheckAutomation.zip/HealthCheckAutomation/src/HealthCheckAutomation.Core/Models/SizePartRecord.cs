namespace HealthCheckAutomation.Core.Models;

/// <summary>
/// One row from one of the SIZE_PARTS workbooks. These are matched back to the
/// main extract by ApplicationName + RecordType + FileName (or by the same
/// derived pattern as the main extract, when exact file name match fails).
/// </summary>
public class SizePartRecord
{
    public string SourceFile { get; set; } = "";     // which of the 3 workbooks this came from
    public int RowNumber { get; set; }

    public string? ApplicationName { get; set; }
    public string? RecordType { get; set; }
    public string? FileName { get; set; }

    /// <summary>Raw value as read from the sheet - kept so we can tell N/A vs blank vs a real number apart.</summary>
    public string? FileSizeRaw { get; set; }

    /// <summary>Parsed numeric size in bytes, null if missing/blank/unparsable/N-A.</summary>
    public double? FileSizeBytes { get; set; }
}
