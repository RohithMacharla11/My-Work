namespace HealthCheckAutomation.Core.Models;

/// <summary>
/// One row of the final Health Check output: one unique
/// (ApplicationName, RecordType, FileNamePattern) scenario, with all
/// 7 derived columns plus an audit trail explaining any gaps/assumptions.
/// </summary>
public class HealthCheckOutputRow
{
    public string ApplicationName { get; set; } = "";
    public string RecordType { get; set; } = "";

    /// <summary>Human-readable regex-like pattern derived for this group, e.g. "Prefix_{DATE}_{TIME}.csv".</summary>
    public string FileNamePattern { get; set; } = "";

    // ----- the 7 required columns -----
    public string FrequencyType { get; set; } = "Unknown";     // Daily/Weekly/Monthly/Quarterly/Yearly/Unknown
    public string FrequencyDay { get; set; } = "";              // e.g. "Monday" / "15" / "" for Daily
    public string ExpectedStartTime { get; set; } = "";          // HH:mm
    public string ExpectedEndTime { get; set; } = "";            // HH:mm
    public string ExcludingDay { get; set; } = "";               // "Weekends" / "Saturday" / "" / specific list

    public double? MinimumFileSizeBytes { get; set; }
    public double? MaximumFileSizeBytes { get; set; }

    // ----- audit / traceability, not in the "5 (or 7) required columns" but needed to trust the output -----
    public int TotalFilesInGroup { get; set; }
    public int FilesWithParsedDate { get; set; }
    public int FilesUnparsedDate { get; set; }
    public int FilesWithSize { get; set; }
    public int FilesMissingSize { get; set; }
    public List<string> Issues { get; } = new();

    public void AddIssue(string message) => Issues.Add(message);
}
