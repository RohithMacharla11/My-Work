using HealthCheckAutomation.App.ExcelIO;
using HealthCheckAutomation.Core.Engine;

// --------------------------------------------------------------------------
// Usage:
//   HealthCheckAutomation.App <templatePath.xlsx> <extractPath.xlsx> <sizePartsFolder> <outputPath.xlsx>
//
// templatePath  = the master pattern list (Application Name, Record Type, File pattern, ...)
//                 e.g. Final_health_check_template.xlsx
// extractPath   = the flat main extract (Healthcheck_extract_filenames.xlsx)
// sizePartsFolder = folder of SIZE_PARTS workbooks
// outputPath    = where to write the filled-in Final_Health_Check.xlsx
//
// Example:
//   dotnet run --project src/HealthCheckAutomation.App -- \
//       "D:\data\Final_health_check_template.xlsx" \
//       "D:\data\Healthcheck_extract_filenames.xlsx" \
//       "D:\data\SIZE_PARTS" \
//       "D:\data\Final_Health_Check.xlsx"
// --------------------------------------------------------------------------

if (args.Length < 4)
{
    Console.WriteLine("Usage: HealthCheckAutomation.App <templatePath.xlsx> <extractPath.xlsx> <sizePartsFolder> <outputPath.xlsx>");
    return 1;
}

var templatePath = args[0];
var extractPath = args[1];
var sizePartsFolder = args[2];
var outputPath = args[3];

var sw = System.Diagnostics.Stopwatch.StartNew();

Console.WriteLine($"Reading pattern template: {templatePath}");
var patterns = PatternTemplateReader.Read(templatePath);
Console.WriteLine($"  {patterns.Count} known scenarios (pattern rows) read in {sw.Elapsed}");

Console.WriteLine($"Reading extract: {extractPath}");
var extract = ExtractReader.Read(extractPath);
Console.WriteLine($"  {extract.Count} rows read in {sw.Elapsed}");

Console.WriteLine($"Reading SIZE_PARTS folder: {sizePartsFolder}");
var sizeParts = SizePartsReader.ReadFolder(sizePartsFolder);
Console.WriteLine($"  {sizeParts.Count} size rows read in {sw.Elapsed}");

Console.WriteLine("Running health check engine...");
var engine = new HealthCheckEngine();
var result = engine.Run(patterns, extract, sizeParts);
Console.WriteLine($"  {result.Rows.Count} scenarios filled, {result.UnmatchedFiles.Count} unmatched files, in {sw.Elapsed}");

Console.WriteLine($"Writing output: {outputPath}");
ResultWriter.Write(result, outputPath);

var withIssues = result.Rows.Count(r => r.Issues.Count > 0);
var unknownFreq = result.Rows.Count(r => r.FrequencyType == "Unknown");
var noFilesMatched = result.Rows.Count(r => r.TotalFilesInGroup == 0);

Console.WriteLine();
Console.WriteLine("=== Summary ===");
Console.WriteLine($"Total template scenarios : {result.Rows.Count}");
Console.WriteLine($"Scenarios w/ 0 files      : {noFilesMatched}");
Console.WriteLine($"Scenarios w/ issues       : {withIssues}");
Console.WriteLine($"Unknown frequency         : {unknownFreq}");
Console.WriteLine($"Unmatched extract files   : {result.UnmatchedFiles.Count}");
Console.WriteLine($"Total time                : {sw.Elapsed}");

return 0;
