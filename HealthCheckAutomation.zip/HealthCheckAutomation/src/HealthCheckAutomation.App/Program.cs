using HealthCheckAutomation.App.ExcelIO;
using HealthCheckAutomation.Core.Engine;

// --------------------------------------------------------------------------
// Usage:
//   HealthCheckAutomation.App <extractPath.xlsx> <sizePartsFolder> <outputPath.xlsx>
//
// Example:
//   dotnet run --project src/HealthCheckAutomation.App -- \
//       "C:\data\extract.xlsx" "C:\data\SIZE_PARTS" "C:\data\Final_Health_Check.xlsx"
// --------------------------------------------------------------------------

if (args.Length < 3)
{
    Console.WriteLine("Usage: HealthCheckAutomation.App <extractPath.xlsx> <sizePartsFolder> <outputPath.xlsx>");
    return 1;
}

var extractPath = args[0];
var sizePartsFolder = args[1];
var outputPath = args[2];

var sw = System.Diagnostics.Stopwatch.StartNew();

Console.WriteLine($"Reading extract: {extractPath}");
var extract = ExtractReader.Read(extractPath);
Console.WriteLine($"  {extract.Count} rows read in {sw.Elapsed}");

Console.WriteLine($"Reading SIZE_PARTS folder: {sizePartsFolder}");
var sizeParts = SizePartsReader.ReadFolder(sizePartsFolder);
Console.WriteLine($"  {sizeParts.Count} size rows read in {sw.Elapsed}");

Console.WriteLine("Running health check engine...");
var engine = new HealthCheckEngine();
var result = engine.Run(extract, sizeParts);
Console.WriteLine($"  {result.Count} scenarios derived in {sw.Elapsed}");

Console.WriteLine($"Writing output: {outputPath}");
ResultWriter.Write(result, outputPath);

var withIssues = result.Count(r => r.Issues.Count > 0);
var unknownFreq = result.Count(r => r.FrequencyType == "Unknown");

Console.WriteLine();
Console.WriteLine("=== Summary ===");
Console.WriteLine($"Total scenarios     : {result.Count}");
Console.WriteLine($"Scenarios w/ issues : {withIssues}");
Console.WriteLine($"Unknown frequency   : {unknownFreq}");
Console.WriteLine($"Total time          : {sw.Elapsed}");

return 0;
