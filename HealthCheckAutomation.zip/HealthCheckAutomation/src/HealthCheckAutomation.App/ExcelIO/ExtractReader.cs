using ClosedXML.Excel;
using HealthCheckAutomation.Core.Models;

namespace HealthCheckAutomation.App.ExcelIO;

/// <summary>
/// Reads the flat main extract workbook into ExtractRecord objects, matching columns
/// by header text (see HeaderMap) rather than fixed positions, so column re-ordering
/// in the source file doesn't break the read.
/// </summary>
public static class ExtractReader
{
    public static List<ExtractRecord> Read(string filePath, string? sheetName = null)
    {
        using var wb = new XLWorkbook(filePath);
        var ws = sheetName != null ? wb.Worksheet(sheetName) : wb.Worksheets.First();
        var map = new HeaderMap(ws);

        int colApp = map.Find("Applicationname", "Application Name") ?? throw new InvalidOperationException("Column 'Applicationname' not found.");
        int colRecord = map.Find("RecordType", "Record Type") ?? throw new InvalidOperationException("Column 'RecordType' not found.");
        int? colContainer = map.Find("Container Key", "ContainerKey");
        int? colDocKey = map.Find("Document Key", "DocumentKey");
        int? colName = map.Find("Name");
        int? colReportdate = map.Find("Reportdate", "Report Date");
        int? colReportdateCalc = map.Find("ReportdateCalc", "Report Date Calc");
        int? colArchiveDelete = map.Find("DocumentArchiveDeleteDate");
        int? colCreated = map.Find("Created Date", "CreatedDate");
        int? colDisposition = map.Find("Disposition");
        int? colDispositionMonths = map.Find("DispositionInMonths");
        int? colDispositionAfter = map.Find("DispositionAfter");
        int? colArchiveDuration = map.Find("ArchiveDurationInDays");
        int? colLegalHold = map.Find("LegalHold");
        int? colStatus = map.Find("Status");
        int? colDataClass = map.Find("DataClassification");
        int? colItStorage = map.Find("ItStorageRequirement");

        var results = new List<ExtractRecord>();
        var lastRow = ws.LastRowUsed()?.RowNumber() ?? 1;

        for (int r = 2; r <= lastRow; r++)
        {
            var row = ws.Row(r);
            if (row.IsEmpty()) continue;

            var rec = new ExtractRecord
            {
                RowNumber = r,
                ApplicationName = Str(row, colApp),
                RecordType = Str(row, colRecord),
                ContainerKey = StrOpt(row, colContainer),
                DocumentKey = StrOpt(row, colDocKey),
                Name = StrOpt(row, colName),
                Reportdate = DateOpt(row, colReportdate),
                ReportdateCalc = DateOpt(row, colReportdateCalc),
                DocumentArchiveDeleteDate = DateOpt(row, colArchiveDelete),
                CreatedDate = DateOpt(row, colCreated),
                Disposition = StrOpt(row, colDisposition),
                DispositionInMonths = DoubleOpt(row, colDispositionMonths),
                DispositionAfter = StrOpt(row, colDispositionAfter),
                ArchiveDurationInDays = DoubleOpt(row, colArchiveDuration),
                LegalHold = StrOpt(row, colLegalHold),
                Status = StrOpt(row, colStatus),
                DataClassification = StrOpt(row, colDataClass),
                ItStorageRequirement = StrOpt(row, colItStorage),
            };

            if (string.IsNullOrWhiteSpace(rec.ApplicationName) && string.IsNullOrWhiteSpace(rec.RecordType) && string.IsNullOrWhiteSpace(rec.Name))
                continue; // fully blank row - skip rather than count as data

            results.Add(rec);
        }

        return results;
    }

    private static string Str(IXLRow row, int col) => row.Cell(col).GetString().Trim();
    private static string? StrOpt(IXLRow row, int? col)
    {
        if (col is null) return null;
        var v = row.Cell(col.Value).GetString().Trim();
        return string.IsNullOrWhiteSpace(v) || IsNullToken(v) ? null : v;
    }

    private static DateTime? DateOpt(IXLRow row, int? col)
    {
        if (col is null) return null;
        var cell = row.Cell(col.Value);
        if (cell.IsEmpty()) return null;
        if (cell.TryGetValue(out DateTime dt)) return dt;
        var s = cell.GetString().Trim();
        if (IsNullToken(s) || string.IsNullOrWhiteSpace(s)) return null;
        return DateTime.TryParse(s, out var parsed) ? parsed : null;
    }

    private static double? DoubleOpt(IXLRow row, int? col)
    {
        if (col is null) return null;
        var cell = row.Cell(col.Value);
        if (cell.IsEmpty()) return null;
        if (cell.TryGetValue(out double d)) return d;
        var s = cell.GetString().Trim();
        if (IsNullToken(s) || string.IsNullOrWhiteSpace(s)) return null;
        return double.TryParse(s, out var parsed) ? parsed : null;
    }

    private static bool IsNullToken(string s) =>
        s.Equals("N/A", StringComparison.OrdinalIgnoreCase) ||
        s.Equals("NA", StringComparison.OrdinalIgnoreCase) ||
        s.Equals("NULL", StringComparison.OrdinalIgnoreCase) ||
        s == "-";
}
