using ClosedXML.Excel;
using HealthCheckAutomation.Core.Models;

namespace HealthCheckAutomation.App.ExcelIO;

/// <summary>
/// Writes the final Health Check output to a formatted workbook:
///   - "Health Check" sheet: one row per scenario, with the 7 required columns
///     plus size columns and audit counts, headers bolded/frozen, columns
///     auto-fitted, empty/Unknown cells filled to make gaps easy to spot.
///   - "Issues" sheet: a flat list of every audit issue raised, one row each,
///     so nothing found during processing gets buried inside a single cell.
/// </summary>
public static class ResultWriter
{
    public static void Write(List<HealthCheckOutputRow> rows, string outputPath)
    {
        using var wb = new XLWorkbook();
        WriteMainSheet(wb, rows);
        WriteIssuesSheet(wb, rows);
        wb.SaveAs(outputPath);
    }

    private static void WriteMainSheet(XLWorkbook wb, List<HealthCheckOutputRow> rows)
    {
        var ws = wb.Worksheets.Add("Health Check");

        string[] headers =
        {
            "Application Name", "Record Type", "File Name Pattern",
            "Frequency Type", "Frequency Day", "Expected Start Time", "Expected End Time", "Excluding Day",
            "Minimum File Size (bytes)", "Maximum File Size (bytes)",
            "Total Files", "Files With Date", "Files Unparsed Date", "Files With Size", "Files Missing Size",
            "Issues"
        };

        for (int i = 0; i < headers.Length; i++)
            ws.Cell(1, i + 1).Value = headers[i];

        var headerRow = ws.Row(1);
        headerRow.Style.Font.Bold = true;
        headerRow.Style.Fill.BackgroundColor = XLColor.FromArgb(0x1F, 0x4E, 0x79);
        headerRow.Style.Font.FontColor = XLColor.White;
        ws.SheetView.FreezeRows(1);

        int r = 2;
        foreach (var row in rows)
        {
            ws.Cell(r, 1).Value = row.ApplicationName;
            ws.Cell(r, 2).Value = row.RecordType;
            ws.Cell(r, 3).Value = row.FileNamePattern;
            ws.Cell(r, 4).Value = row.FrequencyType;
            ws.Cell(r, 5).Value = row.FrequencyDay;
            ws.Cell(r, 6).Value = row.ExpectedStartTime;
            ws.Cell(r, 7).Value = row.ExpectedEndTime;
            ws.Cell(r, 8).Value = row.ExcludingDay;
            if (row.MinimumFileSizeBytes.HasValue) ws.Cell(r, 9).Value = row.MinimumFileSizeBytes.Value;
            if (row.MaximumFileSizeBytes.HasValue) ws.Cell(r, 10).Value = row.MaximumFileSizeBytes.Value;
            ws.Cell(r, 11).Value = row.TotalFilesInGroup;
            ws.Cell(r, 12).Value = row.FilesWithParsedDate;
            ws.Cell(r, 13).Value = row.FilesUnparsedDate;
            ws.Cell(r, 14).Value = row.FilesWithSize;
            ws.Cell(r, 15).Value = row.FilesMissingSize;
            ws.Cell(r, 16).Value = string.Join(" | ", row.Issues);

            if (row.FrequencyType == "Unknown")
                ws.Range(r, 4, r, 5).Style.Fill.BackgroundColor = XLColor.FromArgb(0xFF, 0xF2, 0xCC);
            if (row.Issues.Count > 0)
                ws.Cell(r, 16).Style.Fill.BackgroundColor = XLColor.FromArgb(0xFC, 0xE4, 0xD6);

            r++;
        }

        ws.Columns().AdjustToContents();
        ws.RangeUsed()?.SetAutoFilter();
    }

    private static void WriteIssuesSheet(XLWorkbook wb, List<HealthCheckOutputRow> rows)
    {
        var ws = wb.Worksheets.Add("Issues");
        ws.Cell(1, 1).Value = "Application Name";
        ws.Cell(1, 2).Value = "Record Type";
        ws.Cell(1, 3).Value = "File Name Pattern";
        ws.Cell(1, 4).Value = "Issue";
        ws.Row(1).Style.Font.Bold = true;
        ws.SheetView.FreezeRows(1);

        int r = 2;
        foreach (var row in rows)
        {
            foreach (var issue in row.Issues)
            {
                ws.Cell(r, 1).Value = row.ApplicationName;
                ws.Cell(r, 2).Value = row.RecordType;
                ws.Cell(r, 3).Value = row.FileNamePattern;
                ws.Cell(r, 4).Value = issue;
                r++;
            }
        }

        ws.Columns().AdjustToContents();
        if (r > 2) ws.RangeUsed()?.SetAutoFilter();
    }
}
