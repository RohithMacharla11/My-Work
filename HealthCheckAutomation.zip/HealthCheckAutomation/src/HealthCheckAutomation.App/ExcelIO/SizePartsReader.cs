using ClosedXML.Excel;
using HealthCheckAutomation.Core.Models;

namespace HealthCheckAutomation.App.ExcelIO;

/// <summary>
/// Reads all workbooks in the SIZE_PARTS folder into SizePartRecord objects.
/// Column names are guessed via HeaderMap using the likely candidates seen in the
/// screenshots (ApplicationName, RecordType, FileName / Name, FileSize) - adjust
/// the candidate lists below once the exact SIZE_PARTS headers are confirmed.
/// </summary>
public static class SizePartsReader
{
    public static List<SizePartRecord> ReadFolder(string folderPath)
    {
        var results = new List<SizePartRecord>();
        foreach (var file in Directory.GetFiles(folderPath, "*.xlsx"))
        {
            if (Path.GetFileName(file).StartsWith("~$")) continue; // skip Excel lock files
            results.AddRange(ReadFile(file));
        }
        return results;
    }

    public static List<SizePartRecord> ReadFile(string filePath)
    {
        var results = new List<SizePartRecord>();
        using var wb = new XLWorkbook(filePath);

        foreach (var ws in wb.Worksheets)
        {
            var map = new HeaderMap(ws);
            int? colApp = map.Find("Applicationname", "Application Name", "ApplicationName");
            int? colRecord = map.Find("RecordType", "Record Type");
            int? colFileName = map.Find("FileName", "File Name", "Name");
            int? colFileSize = map.Find("FileSize", "File Size");

            if (colApp is null || colRecord is null || colFileSize is null)
                continue; // not a data sheet in the expected layout - skip quietly

            var lastRow = ws.LastRowUsed()?.RowNumber() ?? 1;
            for (int r = 2; r <= lastRow; r++)
            {
                var row = ws.Row(r);
                if (row.IsEmpty()) continue;

                var app = row.Cell(colApp.Value).GetString().Trim();
                var record = row.Cell(colRecord.Value).GetString().Trim();
                if (string.IsNullOrWhiteSpace(app) && string.IsNullOrWhiteSpace(record)) continue;

                var raw = row.Cell(colFileSize.Value).GetString().Trim();
                double? size = null;
                if (row.Cell(colFileSize.Value).TryGetValue(out double d))
                    size = d;
                else if (!string.IsNullOrWhiteSpace(raw) && !IsNullToken(raw) && double.TryParse(raw, out var parsed))
                    size = parsed;

                results.Add(new SizePartRecord
                {
                    SourceFile = Path.GetFileName(filePath),
                    RowNumber = r,
                    ApplicationName = app,
                    RecordType = record,
                    FileName = colFileName != null ? row.Cell(colFileName.Value).GetString().Trim() : null,
                    FileSizeRaw = raw,
                    FileSizeBytes = size
                });
            }
        }

        return results;
    }

    private static bool IsNullToken(string s) =>
        s.Equals("N/A", StringComparison.OrdinalIgnoreCase) ||
        s.Equals("NA", StringComparison.OrdinalIgnoreCase) ||
        s.Equals("NULL", StringComparison.OrdinalIgnoreCase) ||
        s == "-";
}
