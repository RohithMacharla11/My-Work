using ClosedXML.Excel;
using HealthCheckAutomation.Core.Models;

namespace HealthCheckAutomation.App.ExcelIO;

/// <summary>
/// Reads the pattern template workbook - the master list of known
/// (ApplicationName, RecordType, FilePattern) scenarios, e.g. Final_health_check_template.xlsx.
/// This is the list the engine fills in; it is never derived from the extract.
/// </summary>
public static class PatternTemplateReader
{
    public static List<PatternRule> Read(string filePath, string? sheetName = null)
    {
        using var wb = new XLWorkbook(filePath);
        var ws = sheetName != null ? wb.Worksheet(sheetName) : wb.Worksheets.First();
        var map = new HeaderMap(ws);

        int colApp = map.Find("Application Name", "ApplicationName") ?? throw new InvalidOperationException("Column 'Application Name' not found in template.");
        int colRecord = map.Find("Record Type", "RecordType") ?? throw new InvalidOperationException("Column 'Record Type' not found in template.");
        int colPattern = map.Find("File pattern", "File Pattern", "FilePattern", "File Name Pattern") ?? throw new InvalidOperationException("Column 'File pattern' not found in template.");
        int? colBizContact = map.Find("Primary Business Contact");
        int? colItContact = map.Find("Primary IT Contact");

        var results = new List<PatternRule>();
        var lastRow = ws.LastRowUsed()?.RowNumber() ?? 1;

        for (int r = 2; r <= lastRow; r++)
        {
            var row = ws.Row(r);
            if (row.IsEmpty()) continue;

            var app = row.Cell(colApp).GetString().Trim();
            var record = row.Cell(colRecord).GetString().Trim();
            var pattern = row.Cell(colPattern).GetString().Trim();

            if (string.IsNullOrWhiteSpace(app) && string.IsNullOrWhiteSpace(record) && string.IsNullOrWhiteSpace(pattern))
                continue;

            results.Add(new PatternRule
            {
                RowNumber = r,
                ApplicationName = app,
                RecordType = record,
                FilePatternRaw = pattern,
                PrimaryBusinessContact = colBizContact != null ? row.Cell(colBizContact.Value).GetString().Trim() : null,
                PrimaryITContact = colItContact != null ? row.Cell(colItContact.Value).GetString().Trim() : null
            });
        }

        return results;
    }
}
