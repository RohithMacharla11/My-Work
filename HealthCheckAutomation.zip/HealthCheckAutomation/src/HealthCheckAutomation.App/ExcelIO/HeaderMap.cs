using ClosedXML.Excel;

namespace HealthCheckAutomation.App.ExcelIO;

/// <summary>
/// Reads the header row of a worksheet and lets callers look up a column index by
/// header text, tolerant of spacing/casing differences (e.g. "Applicationname",
/// "Application Name" and "application_name" all match the same lookup key) so a
/// mismatched source workbook doesn't silently drop a whole column.
/// </summary>
public class HeaderMap
{
    private readonly Dictionary<string, int> _map = new();

    public HeaderMap(IXLWorksheet ws, int headerRow = 1)
    {
        var row = ws.Row(headerRow);
        var lastCol = ws.LastColumnUsed()?.ColumnNumber() ?? 0;
        for (int c = 1; c <= lastCol; c++)
        {
            var text = row.Cell(c).GetString();
            if (string.IsNullOrWhiteSpace(text)) continue;
            _map[Normalize(text)] = c;
        }
    }

    public int? Find(params string[] candidates)
    {
        foreach (var candidate in candidates)
            if (_map.TryGetValue(Normalize(candidate), out var col))
                return col;
        return null;
    }

    private static string Normalize(string s) =>
        new string(s.Where(char.IsLetterOrDigit).ToArray()).ToLowerInvariant();
}
