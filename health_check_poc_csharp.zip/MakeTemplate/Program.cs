// MakeTemplate — creates a starter Health Check Requirements Template (template.xlsx).
// Run this once to generate the template — then edit it yourself in Excel to
// add/change application rows. You do NOT need to re-run this after that;
// it's only here so you have a correctly-formatted starting point.
//
// Usage:
//   dotnet run --project MakeTemplate

using System;
using System.Collections.Generic;
using ClosedXML.Excel;

namespace HealthCheckPOC
{
    internal static class MakeTemplateProgram
    {
        private static readonly string[] Headers =
        {
            "Application Name", "Record Type", "File Pattern (Regex)",
            "Frequency Type", "Frequency Day", "Excluding Day",
            "Expected Start Time", "Expected End Time",
            "Min File Size (KB)", "Max File Size (KB)",
            "Source Folder", "Destination Folder"
        };

        private static readonly object[][] ExampleRows =
        {
            new object[]
            {
                "EXANE", "UnitedStates", @"EXANE_\d{8}_FINAL_US.*\.xlsm$",
                "Weekly", "Monday", "Saturday,Sunday",
                "04:00", "06:00", 1, 10240,
                @"source_folders\EXANE_UnitedStates", @"destination_folders\EXANE_UnitedStates"
            },
            new object[]
            {
                "AMLUSSAR", "SAR", @"SAR_\d{8}_\d{6,}\.msg$",
                "Weekly", "Monday,Tuesday,Wednesday,Thursday,Friday", "Saturday,Sunday",
                "13:00", "15:00", 1, 5120,
                @"source_folders\AMLUSSAR_SAR", @"destination_folders\AMLUSSAR_SAR"
            },
        };

        private static readonly (string Field, string Desc)[] LegendNotes =
        {
            ("Application Name", "Name of the application/team sending the file."),
            ("Record Type", "Record type for that application (combined with Application Name + File Pattern, forms the unique key)."),
            ("File Pattern (Regex)", @"Regex that matches the expected filename(s), e.g. EXANE_\d{8}_FINAL_US.*\.xlsm$"),
            ("Frequency Type", "Daily / Weekly / Monthly — informational for now; the actual check uses Frequency Day."),
            ("Frequency Day", "Comma-separated weekday name(s) the file is expected on, e.g. Monday or Monday,Wednesday,Friday. Leave blank to skip this check."),
            ("Excluding Day", "Comma-separated weekday name(s) that should NEVER receive a file, e.g. Saturday,Sunday. Leave blank if none."),
            ("Expected Start Time", "Earliest expected arrival time, 24-hour HH:mm."),
            ("Expected End Time", "Latest expected arrival time, 24-hour HH:mm."),
            ("Min File Size (KB)", "Minimum acceptable file size in KB."),
            ("Max File Size (KB)", "Maximum acceptable file size in KB."),
            ("Source Folder", "Local folder path this application's files land in (relative to where you run the program, or a full path)."),
            ("Destination Folder", "Where files get moved to after processing (recorded only — not used in the POC check logic yet)."),
        };

        private static void Main()
        {
            using var wb = new XLWorkbook();

            // ---- Legend sheet ----
            var legend = wb.Worksheets.Add("Legend");
            legend.Cell(1, 1).Value = "Health Check Requirements Template — How to fill this in";
            legend.Cell(1, 1).Style.Font.Bold = true;
            legend.Cell(1, 1).Style.Font.FontSize = 13;

            int r = 3;
            foreach (var (field, desc) in LegendNotes)
            {
                legend.Cell(r, 1).Value = field;
                legend.Cell(r, 1).Style.Font.Bold = true;
                legend.Cell(r, 2).Value = desc;
                legend.Cell(r, 2).Style.Alignment.WrapText = true;
                r++;
            }
            legend.Column(1).Width = 22;
            legend.Column(2).Width = 90;

            // ---- Requirements Template sheet ----
            var ws = wb.Worksheets.Add("Requirements Template");
            var headerFill = XLColor.FromHtml("#1F4E78");
            for (int c = 0; c < Headers.Length; c++)
            {
                var cell = ws.Cell(1, c + 1);
                cell.Value = Headers[c];
                cell.Style.Font.Bold = true;
                cell.Style.Font.FontColor = XLColor.White;
                cell.Style.Fill.BackgroundColor = headerFill;
                cell.Style.Alignment.WrapText = true;
            }

            var exampleFill = XLColor.FromHtml("#FFF2CC");
            for (int rowIdx = 0; rowIdx < ExampleRows.Length; rowIdx++)
            {
                var rowData = ExampleRows[rowIdx];
                for (int c = 0; c < rowData.Length; c++)
                {
                    var cell = ws.Cell(rowIdx + 2, c + 1);
                    if (rowData[c] is int intVal) cell.Value = intVal;
                    else cell.Value = rowData[c].ToString();
                    cell.Style.Fill.BackgroundColor = exampleFill;
                }
            }

            for (int c = 0; c < Headers.Length; c++)
                ws.Column(c + 1).Width = Math.Max(18, Headers[c].Length + 4);

            ws.SheetView.FreezeRows(1);

            wb.SaveAs("template.xlsx");
            Console.WriteLine("Wrote template.xlsx");
        }
    }
}
