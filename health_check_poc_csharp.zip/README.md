# Health Check POC — C# / .NET version

Same solution as before, rewritten in C#/.NET. Two console apps:

- **MakeTemplate** — generates a starter `template.xlsx` (you already have one included, so you don't need to run this unless you want a fresh blank copy).
- **HealthCheck** — the actual checker: reads `template.xlsx`, scans each application's Source Folder, matches filenames against the regex, checks day/time/size, and writes `health_check_report.xlsx`.

Both use **ClosedXML** (a NuGet package) to read/write `.xlsx` — no Excel installation required on the machine that runs it.

> **Honest note:** my sandbox here doesn't have the .NET SDK installed, so unlike the Python version I could not actually compile and run this C# code before handing it to you — I tested the *exact same logic* in Python end-to-end (day/time/size checks, PASS/FAIL results) and translated it line-for-line into C#, so the logic itself is proven. But please run `dotnet build` first and let me know immediately if you hit any compile errors — I'll fix them right away.

## 1. Folder layout

```
D:\HealthCheckPOC\
├── HealthCheckPOC.sln
├── HealthCheck\
│   ├── HealthCheck.csproj
│   └── Program.cs
├── MakeTemplate\
│   ├── MakeTemplate.csproj
│   └── Program.cs
├── template.xlsx            ← the requirements template — EDIT THIS
├── README.md
├── source_folders\
│   ├── EXANE_UnitedStates\
│   │   ├── EXANE_20260914_FINAL_US_snapshot.xlsm
│   │   └── readme.txt              (ignored — doesn't match the pattern)
│   └── AMLUSSAR_SAR\
│       └── SAR_08262026_140010.msg
└── destination_folders\
    ├── EXANE_UnitedStates\
    └── AMLUSSAR_SAR\
```

## 2. Requirements

- **.NET 8 SDK** — download from https://dotnet.microsoft.com/download if you don't have it.
- No other install needed — `dotnet restore` will pull the ClosedXML NuGet package automatically the first time you build.

## 3. Build

Open a terminal in `D:\HealthCheckPOC\` and run:

```
dotnet restore
dotnet build
```

If this reports any errors, send them to me and I'll fix them immediately.

## 4. The template (`template.xlsx`)

Same format as before — open it in Excel:

- **Legend** tab — explains every column.
- **Requirements Template** tab — the actual data. The two highlighted rows are examples; edit them or add new rows below for each Application Name + Record Type + File Pattern you want to check.

| Column | Notes |
|---|---|
| File Pattern (Regex) | .NET regex, e.g. `EXANE_\d{8}_FINAL_US.*\.xlsm$` |
| Frequency Day | Comma-separated weekdays expected, e.g. `Monday` or `Monday,Wednesday,Friday`. Leave blank to skip this check. |
| Excluding Day | Comma-separated weekdays that should NEVER see a file, e.g. `Saturday,Sunday` |
| Expected Start/End Time | 24-hour `HH:mm` |
| Min/Max File Size (KB) | Leave both blank to skip the size check |
| Source Folder | Path to that application's local folder — relative (like `source_folders\EXANE_UnitedStates`) or a full path |
| Destination Folder | Recorded only for now — not used in the check logic yet |

To add a new application: add a new row in the template, and create a matching folder under `source_folders\` with that path.

To regenerate a blank template from scratch:
```
dotnet run --project MakeTemplate
```

## 5. Running the health check

```
dotnet run --project HealthCheck
```

This reads `template.xlsx`, scans every Source Folder, and writes `health_check_report.xlsx` in the current directory.

Optional flags for different file names/locations:
```
dotnet run --project HealthCheck -- --template myTemplate.xlsx --output myReport.xlsx
```

(Note the extra `--` before the flags — that tells `dotnet run` those arguments belong to the program, not to `dotnet` itself.)

Once built, you can also just run the compiled exe directly without `dotnet run`:
```
HealthCheck\bin\Debug\net8.0\HealthCheck.exe
```

## 6. Reading the report

`health_check_report.xlsx` has one row per file found (or one row saying `NO FILE RECEIVED` if nothing matched the pattern in that folder), with:

- Received Date / Time / Day, and File Size — pulled from the file's filesystem **Last Write Time** and size (no `.go` file or filename parsing in this POC).
- **Frequency Day Check**, **Time Window Check**, **File Size Check** — each PASS / FAIL / SKIPPED individually, so you can see exactly which rule failed.
- **Overall Status** — PASS, FAIL, NO FILE RECEIVED, or ERROR (bad path or bad regex in the template), color-coded green/red/yellow.

## 7. What's intentionally NOT in this POC (later phases)

- Real NAS paths — swap in once you're ready, no code change needed, just update Source Folder in the template.
- `.go` file / filename-embedded date parsing — currently using the file's filesystem Last Write Time only.
- Database-backed template (currently just the Excel file).
- Scheduled/ongoing monitoring — this is a one-time batch run each time you execute it.
- Email alerts on failure.

## 8. Try it yourself first

Run it as-is against the sample data included — with the sample timestamps set, you should see one PASS (EXANE) and one FAIL (AMLUSSAR, landed on a Saturday, which is an excluded day) in the report. That confirms the logic is working before you point it at your real data.
